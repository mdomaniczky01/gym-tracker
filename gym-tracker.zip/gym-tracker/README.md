# Fuerza — Registro de entreno

App personal para registrar pesos y reps por ejercicio. Rutina Push/Pull/Legs precargada y editable. Los datos se guardan en tu propio navegador (no hay servidor ni base de datos), funciona offline y se puede instalar en el celular como app.

## Cómo subirla a Vercel

### Opción A — Desde la web de Vercel (la más simple, sin instalar nada)
1. Subí esta carpeta a un repositorio en GitHub.
2. Entrá a [vercel.com](https://vercel.com), iniciá sesión y tocá **Add New → Project**.
3. Importá el repo. Vercel detecta la config automáticamente (no toques nada).
4. Tocá **Deploy**. En ~20 segundos tenés tu URL.

### Opción B — Desde la terminal
```bash
npm i -g vercel
cd gym-tracker
vercel
```
Seguí las preguntas (aceptá los valores por defecto). Listo.

## Cómo probarla en tu compu antes de subir
```bash
cd gym-tracker
npx serve public
```
Abrí la URL que te muestra (normalmente http://localhost:3000).

## Instalarla en el celular
1. Abrí tu URL de Vercel en el navegador del celu.
2. En el menú del navegador, tocá **Agregar a pantalla de inicio**.
3. Queda como una app: la abrís con un toque y funciona sin internet.

## Importante sobre tus datos
- Los datos viven **solo en el dispositivo** donde los cargás. No se sincronizan entre celular y compu.
- Para no perderlos (cambio de teléfono, limpieza de navegador), entrá a **Ajustes → Exportar** cada tanto y guardá el archivo. Lo restaurás con **Importar**.

## ¿Por qué no es Express?
Vercel corre funciones serverless, no un servidor Express permanente, y no incluye base de datos por defecto. Para una app de registro personal, guardar en el navegador es más simple, más rápido, gratis y funciona offline. Si en algún momento querés sincronizar entre dispositivos, ahí sí conviene sumar un backend con base de datos (por ejemplo Vercel + una DB como Postgres o Supabase).
